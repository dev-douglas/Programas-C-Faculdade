#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include "lista.h"
/*
01 - Crie uma lista duplamente encadeada. Cada item da lista corresponde a um verso de uma m�sica. 
Alem da letra cada item deve conter a qual estrofe o verso pertence
a)cria lista (a.1 inserir verso)
b)remover item (VERSO)
c exibir rimas (versos proximos que terminam na mesma letra)

2 - Crie o crie o exercicio anterior com uma lista circular
*/
int main() {
	setlocale(LC_ALL, "Portuguese");
	int i = 1, op = 0, pos;
	TipoItem item;
	TipoLista Lista;
	cria_lista_vazia(&Lista);
	
	while(0==0){
		while(1==1){
			system("cls");
			printf("Escreva o verso: ");
			gets(item.verso);
			item.estrofe = i;
				
			if (inserir(&Lista, item)){
				system("cls");
				printf("Verso inserido na estrofe %d\n", i);
			}
			do{
				printf("Inserir mais um verso na estrofe %d? 1 Sim - 2 N�o - Op��o: ", i);
				scanf("%d", &op);
			}while(op!=1 && op!=2);
			if(op==2){
				system("cls");
				break;		
			}
			getchar();
		}
		
		do{
			printf("Adicionar outra estrofe? 1 Sim - 2 N�o - Op��o: ");
			scanf("%d", &op);
		}while(op!=1 && op!=2);
			if(op==2){
			break;
		}
		getchar();		
		i++;
	}			
	while(1>0){
		do{
		system("cls");
		printf("O que deseja fazer:\n\n1 - Exibir Cans�o\n2 - Remover Verso\n3 - Exibir Rimas\n4 - Finalizar Programa\n\nOp��o: ");
		scanf("%d", &op);
	}while(op<1 || op>4);
	getchar();
	switch(op){
		case 1:
			system("cls");
			printf("Cans�o:\n\n");
			imprimir(Lista);
			break; 
		case 2:
			printf("Digite o verso que deseja remover: ");
			gets(item.verso);
			printf("Digite o numero da estrofe: ");
			scanf("%d", &item.estrofe);
			if(BuscaNaLista(&Lista, item) == NULL)
				printf("Verso n�o encontrado na lista\n");
			else{
				remover_item(&Lista, item);
				printf("Verso removido da lista!\n");
			}
			break;
		case 3:
			exibir_rimas(&Lista);
			break;
		case 4:
			exit(0);
	}
	printf("\n");
	system("PAUSE");
	}
	
	
}
