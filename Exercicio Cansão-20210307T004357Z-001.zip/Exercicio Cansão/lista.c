#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "lista.h"

void cria_lista_vazia(TipoLista *Lista){
	Lista->Primeiro        	 	= malloc(sizeof(CelulaLista));	
	Lista->Ultimo            	= Lista->Primeiro;				
	Lista->Primeiro->proximo    = NULL;							
	Lista->Primeiro->anterior   = NULL;							
	Lista->tamanho           	= 0;
}

int inserir(TipoLista *Lista, TipoItem item){
	
	if((Lista->Ultimo->proximo = malloc(sizeof(CelulaLista))) == NULL)
    return 0;
    
	Lista->Ultimo->proximo->anterior	= Lista->Ultimo;			
	Lista->Ultimo             			= Lista->Ultimo->proximo;	
  	Lista->Ultimo->Item       			= item;						
  	Lista->Ultimo->proximo    			= NULL;						
  	Lista->tamanho++;
  	return 1;
}

int remover_item(TipoLista *Lista, TipoItem item){
	ApontadorLista Aux;
	int i;
  	Aux = Lista->Primeiro->proximo;
  	while (Aux != NULL){ 
    	if(Aux->Item.estrofe == item.estrofe){
      	i = 0;
      	while(Aux->Item.verso[i] == item.verso[i] && Aux->Item.verso[i] != '\0' && item.verso[i] != '\0'){
      		i++;
		}
		if(Aux->Item.verso[i] == '\0' && item.verso[i] == '\0')
      	break;
	  }  
      Aux = Aux->proximo;
    }
    
	if(Aux->proximo != NULL)	
    	Aux->proximo->anterior = Aux->anterior;
  	Aux->anterior->proximo = Aux->proximo;
  	free(Aux);
  	Lista->tamanho--;
  	return 1;
}

void exibir_rimas(TipoLista *Lista){
	
	ApontadorLista x, y;
	x = Lista->Primeiro->proximo;
	
	int i,r = 0;
	while (r<Lista->tamanho){
		y = x->proximo;
		i = 0;
		while(i<3 || y!=NULL){
			if (x->Item.verso[tamanho_s(x->Item.verso -1)] == y->Item.verso[tamanho_s(y->Item.verso -1)]){
				printf("Rima: %s - %s\n", x->Item.verso, y->Item.verso);				
			}
			i++;
			y = y->proximo;
			
		}
		x	= x->proximo;
	}	
}

int tamanho_s(char s[]){
	int i = 0;
	while(s[i] != '\0'){
		i++;
	}
	return i;
}

void imprimir(TipoLista Lista){
	ApontadorLista Aux;
 	Aux = Lista.Primeiro->proximo;
  	while (Aux != NULL){
		printf("Estrofe: %d - Verso: %s\n",  Aux->Item.estrofe, Aux->Item.verso);
    	Aux = Aux->proximo;
 	}
}

ApontadorLista BuscaNaLista(TipoLista *Lista, TipoItem item){
	ApontadorLista Aux;
	Aux = Lista->Primeiro->proximo;
	int i = 0;
  	while (Aux != NULL){ 
  	
      if(Aux->Item.estrofe == item.estrofe){
      	i = 0;
      	while(Aux->Item.verso[i] == item.verso[i] && Aux->Item.verso[i] != '\0' && item.verso[i] != '\0'){
      		i++;
		}
		if(Aux->Item.verso[i] == '\0' && item.verso[i] == '\0')
      	return Aux;
	  }
        
      Aux = Aux->proximo;
    }
  	return NULL;
}

