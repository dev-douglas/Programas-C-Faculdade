typedef struct{
	char verso[100];
	int estrofe;
}TipoItem;

typedef struct no *ApontadorLista;

typedef struct no {
  TipoItem Item;
  ApontadorLista proximo, anterior;
} CelulaLista;

typedef struct{
	ApontadorLista Primeiro, Ultimo;
  	int tamanho;
}TipoLista;
 
void cria_lista_vazia(TipoLista *lista);//Cria Lista vasia

int inserir(TipoLista *Lista, TipoItem item);//insere no final da lista

void imprimir(TipoLista Lista);//Exibe a lista crescente de acordo com a posi��o

void exibir_rimas(TipoLista *Lista);	//Exibe as rimas da cans�o

ApontadorLista BuscaNaLista(TipoLista *Lista, TipoItem item);//Busca um item na lista

int remover_item(TipoLista *Lista, TipoItem item);//o usu�rio dever� escolher qual item deseja remover e seu 
                                                  //programa deve ajustar os endere�os dos demais itens da lista.
