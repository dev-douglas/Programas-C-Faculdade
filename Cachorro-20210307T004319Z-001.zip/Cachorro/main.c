#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include "cachorro.h"

int main() {
	setlocale(LC_ALL, "Portuguese");
	menu ();
	return 0;
}
