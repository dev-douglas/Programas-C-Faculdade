#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#include "cachorro.h"

void menu(){
	struct cadastrar cachorro[1000];
	int op, x=0, variavel, p = 0;
	while(1 == 1){
		do{
		system("cls");
		printf("O que deseja fazer?\n\n1 - Cadastrar Cachorro\n2 - Latir\n3 - Pegar a bolinha\n4 - Dormir\n5 - Sair\n\nOp��o: ");
		scanf("%d", &op);	
		}while(op<1 || op>5);
		if(op == 1){
		cachorro[p]=cadastro (p);
		p++;	
		}else if(op == 2){
			latir();
		}else if(op == 3){
			printf("Digite a distancia da bolinha (em centimetros): ");
			do{
			scanf("%d", &variavel);	
			}while(variavel<0);
			bolinha(variavel);
		}else if(op == 4){
			printf("Digite o tempo em que o cachorro dever� dormir(em segundos): ");
			do{
			scanf("%d", &variavel);	
			}while(variavel<0);
			dormir(variavel);
		}else if(op == 5){
			exit(0);
		}	
	}	
}

CAO cadastro(int x){
	struct cadastrar cachorro[1000];
	cachorro[x].nome = nome(cachorro[x].nome, x)
	printf("Digite a ra�a do cachorro: ");
	gets(cachorro[x].raca);
	printf("Digite a cor do cachorro: ");
	gets(cachorro[x].cor);
	printf("Digite a data de nascimento do cachorro\nDIA:  ");
	do{
		scanf("%d", &cachorro[x].dia);	
	}while(cachorro[x].dia<1 || cachorro[x].dia>31);
	printf("M�S: ");
	do{
		scanf("%d", &cachorro[x].mes);	
	}while(cachorro[x].mes<1 || cachorro[x].mes>12);
	printf("ANO: ");
	do{
		scanf("%d", &cachorro[x].ano);	
	}while(cachorro[x].ano<0);
	if(x == 0){
		cachorro[x].id = 201600;
		printf("Identidade do cachorro: %d\n\n",cachorro[x].id);
	}else{
		cachorro[x].id = cachorro[x-1].id + 1;
		printf("Identidade do cachorro: %d\n\n",cachorro[x].id);
	}
	printf("Cachorro cadastrado! - Precione enter para voltar!\n");
	getch();
	system("cls");
	return cachorro[x];
}

char nome(char nome, int x){
	struct cadastrar cachorro[1000];
	printf("Digite o nome do cachorro: ");
	gets(cachorro[x].nome);
	return cachorro[x].nome;
}

void latir(){
	system("cls");
	printf("Woof, Woof!\n\nPrecione enter para voltar!\n");
	getch();
}

void bolinha(int posicao){
	int s = 0;
		while (0<1) {
			Sleep (3);
			system("cls");
			s++;
			printf("Posi��o do cachorro: %dcm da posi��o inicial", s);			
			if(s==posicao){
				printf("\nO cachorro pegou a bolinha!");
				Sleep (2000);
				while (0<1) {
			Sleep (3);
			system("cls");
			s--;
			printf("Posi��o do cachorro: %dcm da posi��o inicial", s);			
			if(s==0){
				printf("\nO cachorro entregou a bolinha ao dono!\n\nPrecione enter para voltar.");
				getch();
				break;
			}
		}	
				break;
			}
		}
}

void dormir (int segundos){
	system("cls");
	printf("O Cachorro est� dormindo - 00: 00: 00");
	int s = 0, m = 0, h = 0, cont = 0;
		while (0<1) {
			Sleep (1000);
			s++;
			cont++;
			system("cls");

			if (s > 59) {
				m++;
				s = 0;
			}
			if (m > 59) {
				h++;
				m = 0;
			}
			if (h > 23) {
				h = 0;
			}
			if(h<10 && m<10 && s<10){
				printf("O Cachorro est� dormindo - 0%d: 0%d: 0%d", h, m, s);
			}else if(h<10 && m<10){
				printf("O Cachorro est� dormindo - 0%d: 0%d: %d", h, m, s);
			}else if(h<10){
				printf("O Cachorro est� dormindo - 0%d: 0%d: %d", h, m, s);
			}else{
				printf("O Cachorro est� dormindo - %d: %d: %d", h, m, s);
			}
			if (cont == segundos){
				break;
			}
		}
		system("cls");
	printf("Woof, Woof! - O Cachorro latiu!\n\nPrecione enter para voltar\n");
	getch();
}
