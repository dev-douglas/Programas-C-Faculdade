typedef struct cadastrar{
	char nome[25], raca[25], cor[15];
	int id , dia, mes, ano;
}CAO, cachorro[1000];

void menu();

CAO cadastro();//Cadastra cachorro

char nome(char nome, int x);

void latir();//Exibe latido na tela

void bolinha(int posicao);//Faz o cachorro busbar a bolinha e mostra a posi��o dele durante o processo

void dormir(int segundos);//Define um tempo para o cachorro dormir, e exibe um latido na tela quando acordar 


