#include <stdio.h>
#include <stdlib.h>
#include "radixsort.h"

int** Aloca_Matriz(int Linhas,int Colunas){//Radix
 
	int i,j;
 
	int **m = (int**)malloc(Linhas * sizeof(int*));
 
	for (i = 0; i < Linhas; i++){
		m[i] = (int*) malloc(Colunas * sizeof(int)); 
		for (j = 0; j < Colunas; j++){ 
			m[i][j] = 0; 
		}
	}
return m; //Retorna o Ponteiro para a Matriz Alocada
}

int radixsort(int *vetor, int tamanho){
	int **balde_MSD, **balde_LSD, i, j, h, aux;
	balde_MSD = Aloca_Matriz(10,tamanho);
	balde_LSD = Aloca_Matriz(10,tamanho);
	
	for(i = 0; i<10; i++){
		for(j = 0; j<=tamanho; j++){
			balde_MSD[i][j] = -1;
			balde_LSD[i][j] = -1;
		}
	}
	
	for (i = 0; i<tamanho; i++){//lSD  
		aux = vetor[i]%10;
		j = 0;
		while(balde_LSD[aux][j] != -1){
			j++;
		}
		balde_LSD[aux][j] = vetor[i];
	}
	
	/*
	for(j = 0; j<10; j++){//Exibe o LSD
		printf("\n");
		for(i = 0; i<tamanho; i++){
			printf("v[%d][%d] = %d\t ", j, i, balde_LSD[j][i]);	
		}
	}
	printf("\n MSD:\n");*/
	
	for(i = 0; i<10; i++){//MSD
		for(j = 0; j<tamanho; j++){
			
			if(balde_LSD[i][j]<10 && balde_LSD[i][j]>=0){
				aux = balde_LSD[i][j]/10;
				h = 0;
				while(balde_MSD[aux][h] != -1){
					h++;
				}
				balde_MSD[aux][h] = balde_LSD[i][j];
			}else if(balde_LSD[i][j]>=10 && balde_LSD[i][j]<100){
				aux = balde_LSD[i][j]/10;
				h = 0;
				while(balde_MSD[aux][h] != -1){
					h++;
				}
				balde_MSD[aux][h] = balde_LSD[i][j];				
			}else if(balde_LSD[i][j]>=100 && balde_LSD[i][j]<1000){
				aux = balde_LSD[i][j]/100;
				h = 0;
				while(balde_MSD[aux][h] != -1){
					h++;
				}
				balde_MSD[aux][h] = balde_LSD[i][j];
			}else if(balde_LSD[i][j]>=1000 && balde_LSD[i][j]<10000){
				aux = balde_LSD[i][j]/1000;
				h = 0;
				while(balde_MSD[aux][h] != -1){
					h++;
				}
				balde_MSD[aux][h] = balde_LSD[i][j];				
			}else if(balde_LSD[i][j]>=10000 && balde_LSD[i][j]<100000){
				aux = balde_LSD[i][j]/10000;
				h = 0;
				while(balde_MSD[aux][h] != -1){
					h++;
				}
				balde_MSD[aux][h] = balde_LSD[i][j];				
			}else if(balde_LSD[i][j]>=100000 && balde_LSD[i][j]<1000000){
				aux = balde_LSD[i][j]/100000;
				h = 0;
				while(balde_MSD[aux][h] != -1){
					h++;
				}
				balde_MSD[aux][h] = balde_LSD[i][j];				
			}else if(balde_LSD[i][j]>=1000000 && balde_LSD[i][j]<10000000){
				aux = balde_LSD[i][j]/1000000;
				h = 0;
				while(balde_MSD[aux][h] != -1){
					h++;
				}
				balde_MSD[aux][h] = balde_LSD[i][j];				
			}else if(balde_LSD[i][j]>=10000000 && balde_LSD[i][j]<100000000){
				aux = balde_LSD[i][j]/10000000;
				h = 0;
				while(balde_MSD[aux][h] != -1){
					h++;
				}
				balde_MSD[aux][h] = balde_LSD[i][j];				
			}else if(balde_LSD[i][j]>=100000000 && balde_LSD[i][j]<1000000000){
				aux = balde_LSD[i][j]/100000000;
				h = 0;
				while(balde_MSD[aux][h] != -1){
					h++;
				}
				balde_MSD[aux][h] = balde_LSD[i][j];				
			}else if(balde_LSD[i][j]>=1000000000 && balde_LSD[i][j]<10000000000){
				aux = balde_LSD[i][j]/1000000000;
				h = 0;
				while(balde_MSD[aux][h] != -1){
					h++;
				}
				balde_MSD[aux][h] = balde_LSD[i][j];				
			}
		}
	}
	/*
	for(j = 0; j<10; j++){printf("\n");//Exibe MSD
		for(i = 0; i<tamanho; i++){
			printf("vs[%d][%d] = %d\t ", j, i, balde_MSD[j][i]);
			
		}
	}*/
	
	for(i = 0; i<10; i++){//Ordena os baldes do MSD com o insertion
		for(j = 0; j<tamanho; j++){

			if(balde_MSD[i][j] > balde_MSD[i][j+1] && balde_MSD[i][j+1] != -1){
				aux = balde_MSD[i][j];
				balde_MSD[i][j] = balde_MSD[i][j+1];
				balde_MSD[i][j+1] = aux;
			}
		}
	}
	
	aux = 0;
	for(i = 0; i<10; i++){//copia os valores previamente ordenados dos baldes MSD para o vetor original
		for(j = 0; j<tamanho; j++){
			if(balde_MSD[i][j] != -1){
				vetor[aux] = balde_MSD[i][j];
				aux++;			
			}
		}
	}
	
	for(i = 0; i<tamanho ;i++){//Finaliza a ordena��o o vetor original com o insertion
		for(j = 0; j<tamanho ;j++){
			if(vetor[j] > vetor[i]){
				aux = vetor[i];
				vetor[i] = vetor[j];
				vetor[j] = aux;
			}
		}
	}
}
