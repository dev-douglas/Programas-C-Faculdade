#include <stdio.h>
#include <stdlib.h>
#include <locale.h>


int main() {
	
	setlocale(LC_ALL, "Portuguese");
	int i = 0, aux = 0, vetor[3];
	printf("Digite a quantidade de n�meros que deseja ordenar: ");
	scanf("%d", &i);	
	while(aux!= i){
		printf("Digite o valor do %d� n�mero: ", aux);
		scanf("%d", &vetor[aux]);
		aux++;
	}
	insertion(&vetor, i);
	printf("\nN�meros ordenados - Insertion\n\n");
	for(aux=0;aux!=i;aux++){
		printf("Vetor[%d] = %d\n", aux, vetor[aux]);
	}

}
