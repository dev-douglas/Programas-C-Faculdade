void insertion(int *vetor, int tamanho);
//Responsavel por ordenar os valores armazenados no vetor em ordem crescente
