#include "insertion.h"
#include <stdio.h>
#include <stdlib.h>

void insertion(int *vetor, int tamanho){
	
	int i, j, n;
		
	for(i = 0; i<tamanho ;i++){
		for(j = 0; j<tamanho ;j++){
			if(vetor[j] > vetor[i]){
				n = vetor[i];
				vetor[i] = vetor[j];
				vetor[j] = n;
			}
		}
	}
}
