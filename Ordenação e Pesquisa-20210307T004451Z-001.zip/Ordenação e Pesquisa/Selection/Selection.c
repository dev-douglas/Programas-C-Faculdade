#include <stdio.h>
#include <stdlib.h>
#include "selection.h"

void selection(int *vetor, int tamanho){
	
	int i = 1, j, n;
	while(i<tamanho){
		if(vetor[i] < vetor[i-1]){
			j = i;
			while(vetor[j] < vetor[j-1] && j >= 0){
				n = vetor[j];
				vetor[j] = vetor[j-1];
				vetor[j-1] = n;	
				j--;
			}
		}
		i++;
	}
}
