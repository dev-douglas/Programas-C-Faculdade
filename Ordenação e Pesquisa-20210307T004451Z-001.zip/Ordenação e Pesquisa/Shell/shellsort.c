int shellsort(int *vetor, int tamanho){
	int m, n, i, j, aux;
	m = tamanho/2;
		
	while(m != 1){
		n = m;
		for(i = 0; i<=n; m++, i++){
			if(vetor[i]>vetor[m] && m<tamanho){
				aux = vetor[i];
				vetor[i] = vetor[m];
				vetor[m] = aux;
			}
		}
		m = n;
		if(m!=1){
			m = m/2;
		}
	}
	
	if(m==1){
		n = m;
		for(i = 0; i<tamanho ;i++){
			for(j = 0; j<tamanho ;j++){
				if(vetor[j] > vetor[i]){
					aux = vetor[i];
					vetor[i] = vetor[j];
					vetor[j] = aux;
				}
			}
		}	
	}
}
