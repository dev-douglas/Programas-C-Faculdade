#include "heapsort.h"

void heapsort(int *vetor, int tamanho){
    int i, aux;
    while(tamanho>0){
    for(i = tamanho-1; i>0; i--){
        if(i%2 != 0){//se a posi��o for impar
            
            if(vetor[i]>vetor[i/2]){
                aux = vetor[i];
                vetor[i] = vetor[i/2];
                vetor[i/2] = aux;
            }          
           
        }else{// se a posi��o for par
              if(vetor[i]>vetor[i/3]){
                aux = vetor[i];
                vetor[i] = vetor[i/3];
                vetor[i/3] = aux;
            }
            if(vetor[i-1]>vetor[i/3]){
                aux = vetor[i-1];
                vetor[i-1] = vetor[i/3];
                vetor[i/3] = aux;
            }
            
			if(i!=2)
            	i--;
        }
    }
	
	//Troca o valor da posi��o 0 com a ultima (passa o maior valor para o final) e diminui o tamanho do vetor
    aux = vetor[0]; 
    vetor[0] = vetor[tamanho-1];
    vetor[tamanho-1] = aux;    	
    tamanho--;

    }
}
