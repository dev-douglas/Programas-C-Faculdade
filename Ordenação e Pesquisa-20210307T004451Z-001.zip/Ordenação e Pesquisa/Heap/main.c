#include <stdio.h>
#include <stdlib.h>
#include "heapsort.h"
//Douglas Lopes 
//3� Periodo

int main() {
    
    int tamanho, i;
    printf("Digite a quantidade de numeros que deseja ordenar: ");
    scanf("%d", &tamanho);
    int vetor[tamanho];
    
    for (i = 0; i<tamanho; i++){
        printf("Digite o valor do vetor[%d]: ", i);
        scanf("%d", &vetor[i]);
    }
    
    heapsort(vetor, tamanho);
    printf("\n\nVetor Ordenado:\n\n");
    for (i = 0; i<tamanho; i++){
        printf("Vetor[%d] = %d\n", i, vetor[i]);
    }
    
    system("PAUSE");
}
