#include <stdio.h>
#include <stdlib.h>
//Douglas Lopes
//Dyuelber Miranda
 
void merge_sort(int *vetor, int p_inicio, int p_final){
	
	int metade;
	
	if(p_inicio<p_final){
		metade = (p_inicio+p_final)/2;									
		merge_sort(vetor, p_inicio, metade);									
		merge_sort(vetor, metade+1,p_final);		
	}else
		return;            

	int *vetor_aux, p1 = p_inicio, p2 = metade + 1, i = 0 ;
	vetor_aux = (int*) malloc ((p_final - p_inicio + 1)* sizeof(int));
	
    while(p1 <= metade || p2  <= p_final){
													
    	if(p1 <= metade && p2 <= p_final){								//caso p1 seja menor ou igual ao final da 1� metade e p2 seja menor ou igual ao final da 2� metade
			if(vetor[p1]<vetor[p2]){									
				vetor_aux[i] = vetor[p1];										
				p1++;														
			}else{																					
				vetor_aux[i] = vetor[p2];																	
				p2++;
			}
			
		}else if(p1 <= metade && p2 > p_final){							//Caso p1 seja menor ou igual ao final da 1� metade	e p2 seja maior que o final da 2� metade							
			vetor_aux[i] = vetor[p1];										
			p1++;
		}else if(p1 > metade && p2 <= p_final){							//Caso p1 seja maior que o final da 1 metade e p2 seja menor ou igual ao final da 2� metade							
			vetor_aux[i] = vetor[p2];										
			p2++;		
		}
		i++;
	}

    for(p1 = p_inicio; p1 <= p_final; p1++){
        vetor[p1] = vetor_aux[p1 - p_inicio];
    }
    free(vetor_aux);
}

void main() {
	
	int tamanho, i;
	
	printf("Digite o tamanho do vetor: ");
	scanf("%d", &tamanho);
	
	int vetor[tamanho];
	
	for(i = 0; i<tamanho; i++){
		printf("Digite um valor para a posicao %d: ", i);
		scanf("%d", &vetor[i]);
	}
	
	merge_sort(vetor, 0, tamanho-1);
	printf("\n\nVetor Ordenado - Merge Sort\n\n");
	for(i = 0; i<tamanho; i++){
		printf("Vetor[%d]: %d\n", i, vetor[i]);
	}
}
