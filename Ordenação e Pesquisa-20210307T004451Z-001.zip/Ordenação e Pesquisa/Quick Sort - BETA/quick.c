#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include "quick.h"

void quicksort(int *vetor, int inicio, int fim){
	
	if(inicio == fim)
		return;	
	
	int pivo, i, j = fim + 1, aux, posicao_pivo;
	
	pivo = vetor[inicio];
	posicao_pivo = inicio;
	
	
	do{	
		for(i = j - 1; i>posicao_pivo; i--){

			if(pivo>=vetor[i]){
				j = posicao_pivo;		
				vetor[posicao_pivo] = vetor[i];
				vetor[i] = pivo;
				posicao_pivo = i;
				break;
			}
		}
		
		if(i == posicao_pivo && j == posicao_pivo){
			posicao_pivo = j;
		}	
		for(j + 1; j<posicao_pivo; j++){
		
			if(pivo<=vetor[j]){
				vetor[posicao_pivo] = vetor[j];
				vetor[j] = pivo;
				aux = j;
				j = posicao_pivo;
				posicao_pivo = aux;
				break;
			}
		}
		if(i == posicao_pivo && j == posicao_pivo){
			posicao_pivo = j;
		}
	}while(i != posicao_pivo && j != posicao_pivo);

	if(posicao_pivo == fim)
		fim--;
	if(posicao_pivo == inicio)
		inicio++;
	
	if(i == posicao_pivo && j == posicao_pivo){
		if(posicao_pivo>= inicio && posicao_pivo<=fim && posicao_pivo+1 <=fim)
			quicksort(vetor, posicao_pivo + 1, fim);
		if(posicao_pivo>= inicio && posicao_pivo<=fim && posicao_pivo-1 >=inicio)
			quicksort(vetor, inicio, posicao_pivo - 1);
	}
}


