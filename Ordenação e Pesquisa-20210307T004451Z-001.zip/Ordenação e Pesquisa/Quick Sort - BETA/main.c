#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include "quick.h"
//Douglas De Melo Lopes //3� Periodo

int main() {
	
	setlocale(LC_ALL, "Portuguese");
	int i = 0, aux = 0;
	
	printf("Digite a quantidade de n�meros que deseja ordenar: ");
	scanf("%d", &i);
	
	int vetor[i];
	
	while(aux!= i){
		printf("Digite o valor do %d� n�mero: ", aux+1);
		scanf("%d", &vetor[aux]);
		aux++;
	}
	quicksort(vetor, 0, i-1);
	printf("\nN�meros ordenados - Quick Sort\n\n");
	for(aux=0;aux!=i;aux++){
		printf("Vetor[%d] = %d\n", aux, vetor[aux]);
	}
}
