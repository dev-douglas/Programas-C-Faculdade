#include <stdio.h>
#include <stdlib.h>
#include "bubble.h"

void bubble(int *vetor, int tamanho){
	int h, i, j, k, tamanho2 = tamanho;
	
	for(h = 0; h<tamanho; h++){
		for(i = 0; i< tamanho2; i++){
			if(vetor[i] > vetor[i+1]){
				j = vetor[i];
				vetor[i] = vetor[i+1];
				vetor[i+1] = j;				
			}
		}
		tamanho2--;
	}
}
