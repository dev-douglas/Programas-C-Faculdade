void bubble(int *vetor, int tamanho);
