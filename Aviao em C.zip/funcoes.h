#include <stdio.h>
#include <stdlib.h>
//2� Periodo
// Nome: DOUGLAS DE MELO LOPES
// Nome: DYUELBER RODRIGUES
typedef struct AVIAO{
	char serie[15];
	int passageiros, portas, trem_pouso, posicao , est_luz;	
}info;
int passageiros(int valor);
//Verifica se os passageiros est�o dentro do aviao
int levantar_voo(int valor);
//Faz o aviao decolar

int abaixar_voo(int valor);
//Faz o aviao pousar

int abaixar_trem_pouso(int valor);
//abaixa o trem de pouso para que o aviao possa pousar

int levantar_trem_pouso(int valor);
//levanta trem de pouso

int abrir_porta(int valor);
//abri porta apenas quando o aviao estiver parado

int fechar_porta(int valor);
//fechar porta sempre que o aviao for voar

int acender_luz(int valor);
//acender luz sempre que o aviao voar

int apagar_luz(int valor);
//apagar luz somente se o aviao estiver no chao

void informacoes();
//pega as informa��es do aviao como posi��o, passageiros, luz etc.
void cabine();
// faz o menu de opcoes do aviao;
