#include <stdio.h>
#include <stdlib.h>
#include "funcoes.h"
//2� Periodo
// Nome: DOUGLAS DE MELO LOPES
// Nome: DYUELBER RODRIGUES
void main() {
	
	informacoes();
	cabine();
	
}
