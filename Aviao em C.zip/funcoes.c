#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoes.h"
//2� Periodo
// Nome: DOUGLAS DE MELO LOPES
// Nome: DYUELBER RODRIGUES
void informacoes(){
	 info AVIAO;
	 printf ("Digite a serie do aviao: ");
	 gets(AVIAO.serie);
	 
	 while(AVIAO.posicao != 1 && AVIAO.posicao != 2){
	 printf ("\nDigite a posicao do aviao\n1 - Voando\n2 - Parado\n");
	 printf ("\nOpcao: ");
	 scanf("%d", &AVIAO.posicao);
	}
	
	if(AVIAO.posicao == 2){
		
		AVIAO.trem_pouso = 2;	//trem de pouso abaixado pois aviao esta parado
		AVIAO.portas = 3;
		while(AVIAO.portas < 1 || AVIAO.portas > 2){
		printf("\nA porta do aviao esta:\n1 - aberta\n2 - fechada\n\nOpcao: ");
		scanf("%d", &AVIAO.portas);
		}
		AVIAO.est_luz = 3;
		while(AVIAO.est_luz < 1 || AVIAO.est_luz > 2){
			printf("\nAs luzes estao:\n1 - Apagadas\n2 - Ligadas\n\nOpcao: ");
		scanf("%d", &AVIAO.est_luz);
		}
		AVIAO.passageiros = 3;
		while(AVIAO.passageiros <1 || AVIAO.passageiros>2){
			printf ("\nOs passageiros estao:\n1 - Dentro do aviao\n2 - Fora do aviao\n\nOpcao: ");
			scanf("%d", &AVIAO.passageiros);
		}
	}else if(AVIAO.posicao == 1){
		AVIAO.portas = 2;	//Portas Fechadas pois o aviao esta voando
		AVIAO.passageiros = 1; // 1 - Dentro do aviao pois o aviao esta voando
		AVIAO.trem_pouso = 3;
		while(AVIAO.trem_pouso < 1 || AVIAO.trem_pouso > 2){
		printf("\nO trem de pouso esta:\n1 - Abaixado\n2 - Levantado\n\nOpcao: ");
		scanf("%d", &AVIAO.trem_pouso);
		}
		AVIAO.est_luz = 2;
	
		}
		
	}
		
void cabine(){
	info AVIAO;
	int opcao=90;
	system ("cls");	
	while(opcao < 1 || opcao > 8){
	
	printf("Aviao Serie: %s\n\n", AVIAO.serie);
		printf("O que deseja fazer?\n\n01 - Levantar Voo\n02 - Abaixar Voo\n03 - Levantar Trem Pouso\n04 - Abaixar Trem Pouso\n05 - Abrir Porta"
		"\n06 - Fechar Porta\n07 - Acender Luz\n08 - Apagar Luz\n09 - Passageiros dentro do aviao\n10 - Passageiros fora do aviao\n\nOpcao: ");
		scanf("%d", &opcao);
	
	if(opcao == 1){// levantar voo
		if(abaixar_voo(AVIAO.posicao) ==1){
			if(fechar_porta(AVIAO.portas) == 1 && acender_luz(AVIAO.est_luz)==1 && passageiros(AVIAO.passageiros)==1){
				system ("cls");
				AVIAO.posicao = 1;//2 parado 1 voando
				printf("Voando\n\n");
				opcao = 11;
			}else if(abrir_porta(AVIAO.portas)==1 && apagar_luz(AVIAO.est_luz)==1){
				system ("cls");
				printf("Nao foi possivel levantar voo pois a porta esta aberta e as luzes estao apagadas\n\n");
				opcao = 11;
			}else if(abrir_porta(AVIAO.portas)==1){
				system ("cls");
				printf("Nao foi possivel levantar voo pois a porta esta aberta\n\n");
				opcao = 11;
			}else if(apagar_luz(AVIAO.est_luz)==1){
				system ("cls");
				printf("Nao foi possivel levantar voo pois as luzes estao apagadas\n\n");
				opcao = 11;
			}else if(passageiros(AVIAO.passageiros)!=1){
					system ("cls");
				printf("Nao foi possivel levantar voo pois os passageiros estao fora do aviao\n\n");
				opcao = 19;
			}
			
		}else if (levantar_voo(AVIAO.posicao)==1){
			system ("cls");
			printf("o aviao ja esta voando\n\n");
			opcao = 91;
		}
	}else if(opcao == 2){// abaixar voo
	
		if(abaixar_voo(AVIAO.posicao)==1 && abaixar_trem_pouso(AVIAO.trem_pouso)==1){
			system ("cls");
			printf("O aviao ja esta parado\n\n");
			opcao = 91;	
		}else if(levantar_trem_pouso(AVIAO.trem_pouso)==1){
			system ("cls");
			printf("Nao e possivel descer o aviao pois o trem de pouso nao esta abaixado\n\n");
			opcao = 19;
		}else{
			system ("cls");
			AVIAO.posicao = 2;
			printf("O aviao esta descendo\n\n");
			opcao = 19;
		}
	}else if(opcao == 3){
		if (abaixar_voo(AVIAO.posicao)==1){
			system ("cls");	
			printf ("Nao e possivel levantar trem de pouso pois o aviao esta parado\n\n");
			opcao = 19;
		}else if(levantar_voo(AVIAO.posicao)==1){
			system ("cls");	
			AVIAO.trem_pouso = 2;
			printf ("Trem de pouso levantado\n\n");
			opcao = 19;
		}
		
	}else if(opcao == 4){
		if(abaixar_voo(AVIAO.posicao)==1){
			system("cls");
			printf("O trem de pouso ja esta abaixado\n\n");
			opcao = 91;
		}else if(levantar_voo(AVIAO.posicao)==1){
			system ("cls");	
			AVIAO.trem_pouso = 1;
			printf("Trem de pouso abaixado\n\n");
			opcao = 91;
		}
		
	}else if(opcao == 5){
		if(levantar_voo(AVIAO.posicao)==1){
			system("cls");
			printf("Nao e possivel abrir a porta pois o aviao esta voando\n\n");
			opcao = 91;
		}else if(abaixar_voo(AVIAO.posicao)==1){
			system("cls");
			AVIAO.portas = 1;
			printf("Porta aberta\n\n");
			opcao = 91;
		}
		
	}else if(opcao == 6){
		if(levantar_voo(AVIAO.posicao)==1){
			system("cls");
			printf("A porta ja esta fechada pois o aviao esta voando\n\n");
			opcao = 19;
		}else{
		system("cls");
		AVIAO.portas = 2;
		printf("Porta fechada\n\n");
		opcao = 91;
		}
	}else if(opcao == 7){
		if(levantar_voo(AVIAO.posicao)==1){
			system("cls");
			printf("As luzes ja estao acesas pois o aviao esta voando\n\n");
			opcao = 19;
		}else{
		system("cls");
		AVIAO.est_luz = 2;
		printf ("Luzes acesas\n\n");
		opcao = 91;
		}
	}else if(opcao == 8){
		if(levantar_voo(AVIAO.posicao)==1){
			system("cls");
			printf("Nao foi possivel apagar as luzes pois o aviao esta voando\n\n");
			opcao = 19;
		}else{
			system ("cls");
			AVIAO.est_luz = 1;
			printf("Luzes apagadas\n\n");
			opcao = 91;
		}
		
	}else if(opcao==9){
		if(passageiros(AVIAO.passageiros)!=1){
		if(levantar_voo(AVIAO.posicao)==1){
			system("cls");	
			printf("Os passageiros nao podem entrar pois o aviao esta voando\n\n");
			opcao= 21;
		}
		else if(fechar_porta(AVIAO.portas)==1){
			system("cls");
			printf("Os passageiros nao podem entrar pois a porta esta fechada\n\n");
			opcao= 21;
		}else{
			system("cls");
			AVIAO.passageiros = 1;
			printf("Os passageiros estao dentro do aviao\n\n");
			opcao= 21;
		}
		}else{
			system("cls");
			printf("Os passageiros ja estao dentro do aviao\n\n");
			opcao= 21;
		}
	}else  if(opcao == 10){
		if(levantar_voo(AVIAO.posicao)==1){
			system("cls");
			printf("Os passageiros nao podem sair pois o aviao esta voando\n\n");
			opcao= 21;
		}else if(abaixar_voo(AVIAO.posicao)==1){
			if(fechar_porta(AVIAO.portas)==1){
				system("cls");
				printf("Os passageiros nao podem sair pois a porta esta fechada\n\n");
				opcao = 21;
			}else if(abrir_porta(AVIAO.portas)==1){
				system("cls");
				AVIAO.passageiros = 2;
				printf("Os passageiros sairam\n\n");
				opcao = 21;
			}
		}
	}
	}
}

int passageiros(int x){
	if (x==1){
		return 1;	
	}else{
		return 0;
	}	
}

int levantar_voo(int x){
	if (x==1){
		return 1;	
	}else{
		return 0;
	}
}

int abaixar_voo(int x){
	if(x==2){
		return 1;
	}else{
		return 0;
	}
}

int abaixar_trem_pouso(int x){
	if (x==1){
		return 1;
	}else{
		return 0;
	}	
}

int levantar_trem_pouso(int x){
	if(x==2){
		return 1;
	}else{
		return 0;
	}
}

int abrir_porta(int x){
	if(x==1){
		return 1;
	}else{
		return 0;
	}
}

int fechar_porta(x){
	if(x==2){
		return 1;
	}else{
		return 0;
	}
}

int acender_luz(int x){
	if(x==2){
		return 1;
	}else{
		return 0;
	}
}

int apagar_luz(int x){
	if(x==1){
		return 1;
	}else{
		return 0;
	}
}
