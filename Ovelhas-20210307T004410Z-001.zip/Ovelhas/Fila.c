#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Fila.h"

void cria_lista_vazia(TipoLista *lista){
	lista->primeiro				=	lista->ultimo;
	lista->ultimo				=	lista->primeiro;//printf("fila!\n");
//	lista->primeiro->anterior	=	lista->ultimo;
//	lista->ultimo->proximo		=	lista->primeiro;
	lista->tamanho =  0;
}

int ListaVazia(TipoLista *Lista){
	return !Lista->tamanho;
}

int insere_na_lista(TipoItem item, TipoLista *lista){
	TipoLista *Aloca;
	if((Aloca = malloc (sizeof(TipoLista))) == NULL)
		return 0;
	if(ListaVazia(lista)){
		lista->primeiro	= Aloca;
		lista->ultimo	= Aloca;
		lista->ultimo->anterior	=	lista->primeiro;
		lista->primeiro->proximo=   lista->ultimo;
	}else{
		lista->primeiro->anterior				=	Aloca;
		lista->primeiro->anterior->proximo	= 	lista->primeiro;
		lista->primeiro = lista->primeiro->anterior;
	}
	lista->primeiro->item       	 = item;
    lista->primeiro->anterior       = lista->ultimo;
    lista->tamanho++;
	return 1;
}

int remover_item(TipoLista *lista){
	TipoLista *remover;
	if(ListaVazia(lista))
		return 0;
	remover = lista->ultimo;
	lista->ultimo->anterior->proximo = lista->ultimo->proximo;
	lista->ultimo 	=  	lista->ultimo->anterior;
	free(remover);
	lista->tamanho--;
	return 1;
}

void exibe_lista(TipoLista lista){
	int i = lista.tamanho;
	TipoLista *listaAux;
	listaAux = lista.primeiro;
	while(i != 0){
		printf("%d� Ovelha - Nome: %s, Peso: %f\n", i, listaAux->item.nome,listaAux->item.peso);
		listaAux = listaAux->proximo;
		i--;
	}
}

float corrida(TipoLista *fila, int quant){
	
	int milissegundos = 0, segundos = 0, minutos = 0, horas = 0, ov = quant, n = 0;
	float tcorrida, tsalto;
	TipoLista Aux;
	fila = fila->ultimo;
		
		while (1 == 1) {
			ovelha:
			tcorrida = fila->item.peso*100;
			tsalto = fila->item.peso*10;
			
			tempo:
			Sleep (1);
			milissegundos++;			

			if (milissegundos > 1000) {
				segundos++;
				milissegundos = 0;
			}
			if (segundos > 59) {
				minutos++;
				segundos = 0;
			}
			if (minutos > 59) {
				horas++;
				minutos = 0;
			}
			if (horas > 23) {
				horas = 0;
			}
					
			if(0 < tcorrida){
					tcorrida--;
					if(milissegundos == 2){
						system("cls");
						printf("Tempo: %d: %d: %d\n\n", horas, minutos, segundos);
						printf("Ovelha %s est� correndo\n", fila->item.nome);	
					}
				
			}else if(0 < tsalto){
				tsalto--;
				if(milissegundos == tsalto || milissegundos == tsalto - 1){
					system("cls");
					printf("Tempo: %d: %d: %d\n\n", horas, minutos, segundos);
					printf("Ovelha %s est� saltando\n", fila->item.nome);
				}
				
			}else{
				if(segundos <=10)
					n++;
				ov--;
				remover_item(fila);
				fila = fila->anterior;
				if(ov == 0)
					goto fim;
				else if(fila->anterior != fila->ultimo)
					goto ovelha;
				
			}
			goto tempo;
			
		}
		fim:
		printf("\nTempo total: %d: %d: %d: %d\n", horas, minutos, segundos, milissegundos);
		printf("Quantidade de ovelhas que pularam o muro antes dos 10 segundos: %d", n);
				

}
