typedef struct{
	char nome[30];	
	float peso;
	int posicao;
}TipoItem;

typedef struct TipoLista{
	TipoItem item;
	int tamanho;
	struct TipoLista *primeiro, *ultimo, *proximo, *anterior;
}TipoLista;

void cria_lista_vazia(TipoLista *lista);//cria a lista vazia

int insere_na_lista(TipoItem item, TipoLista *lista);//insere item no final da lista

int ListaVazia(TipoLista *Lista);//retorna se a lista est� vazia ou n�o (0 ou 1)

//TipoLista* busca_item(TipoItem item, TipoLista *lista);//busca item(nome) na lista

int remover_item(TipoLista *lista);//remove item da lista

void exibe_lista(TipoLista lista);//exibe os itens da lista.

float corrida(TipoLista *fila, int quant);//retorna o tempo de cada ovelha ao pular a cerca (em milissegundos)
