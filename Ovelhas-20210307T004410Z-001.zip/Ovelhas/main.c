#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include "Fila.h"

int main() {
	setlocale(LC_ALL, "Portuguese");
	TipoItem item;
	TipoLista fila;
	cria_lista_vazia(&fila);
	int quant, i, menu, tamanho;
	do{
		system("cls");
		printf("Quantas ovelhas deseja adicionar � fila (max 15)?\nResposta: ");
		scanf("%d", &quant);		
	}while(quant<1 || quant>15);
	
	for(i = 1; i<=quant; i++){
		getchar();
		printf("\nDigite o nome da %d� ovelha: ", i);
		gets(item.nome);
		printf("Digite o peso da %d ovelha: ", i);
		scanf("%f", &item.peso);
		item.posicao = i;
		if(insere_na_lista(item, &fila))
			printf("Ovelha inserida na fila!\n");
	}
	printf("\nPressione enter para ir ao menu!\n");
	getchar();
	while(1==1){
		do{
			system("cls");
			printf("Menu de Op��es\n\n");
			printf("1 - Adicionar ovelha na fila.\n2 - Remover ovelha da fila.\n3 - Exibir Ovelhas.\n4 - Realizar Corrida.\n5 - Finalizar Programa.\n\nOp��o: ");	
			scanf("%d", &menu);
		}while(menu<1 || menu>5);
		getchar();
			system("cls");		
		switch (menu){
			case 1:
				if(quant<=15){
					tamanho = fila.tamanho;
					tamanho++;
					printf("Digite o nome da %d� ovelha: ", tamanho);
					gets(item.nome);
					printf("Digite o peso da %d ovelha: ", tamanho);
					scanf("%f", &item.peso);
					item.posicao = i++;
					if(insere_na_lista(item, &fila))
						printf("Ovelha inserida na fila!\n");
				}else{
					printf("A fila j� possui 15 ovelhas\n");
				}
				break;
			case 2:
				if(remover_item(&fila) == 0)
					printf("N�o foi poss�vel remover pois a fila est� vazia.\n");
				else
					printf("1� Ovelha removida da fila!\n");
				break;
			case 3:
				if(ListaVazia(&fila)){
					printf("A fila est� vazia!\n");
				}else{
					printf("Fila de ovelhas\n\n");
					exibe_lista(fila);
				}
				break;
			case 4:
				corrida(&fila, quant);
				break;
			case 5:
				exit(0);
		}
		printf("\nPressione enter para voltar ao menu!\n");
		getchar();
	}
	return 0;
}
