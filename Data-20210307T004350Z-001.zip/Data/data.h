typedef struct data{
	int dia, mes, ano;
}Tdata;

Tdata CriaData(int d,int m,int a);
int AnoValido(int ano);
int MesValido(int mes);
int bissexto(int ano);
int DiaMesValido (int dia, int mes, int ano);
int DiaValido (int dia);
void MostraData(int hoje);


/*

AnoValido: trata ano negativo
MesValido:: trata negativo e maiorque doze
bissexto: trata se o ano � bissexto
DiaMesValido: se a quantidade de dias � valida para o mes
DiaValido: trata dia negativo e maior que 31
MostraData: Exibe o conteudo da data formado. EX:99/99/9999

*/
