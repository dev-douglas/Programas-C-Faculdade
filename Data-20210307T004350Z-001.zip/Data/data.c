#include <stdio.h>
#include "data.h"

Tdata CriaData(int d, int m, int a){
	Tdata data = {00, 00, 0000};
	if(AnoValido(a))
		data.ano = a;
		
	if (MesValido(m))
	data.mes = m;	
		
	if (diaValido(d))
	data.dia = d;	
	
	if (DiaMesValido (d, m, a) == 1){
		data.mes = m;
		data.dia = d;
	}else{
		data.dia = 0;
	}	
		
		
if(data.dia<10 && data.mes<10){
		printf ("\nDATA: 0%d/0%d/%d", data.dia, data.mes, data.ano);
	}else if(data.dia<10){
		printf ("\nDATA: 0%d/%d/%d", data.dia, data.mes, data.ano);
	}else if(data.mes<10){
		printf ("\nDATA: %d/0%d/%d", data.dia, data.mes, data.ano);
	}else{
		printf ("\nDATA: %d/%d/%d", data.dia, data.mes, data.ano);
	}
	return data;
	
	
}

int diaValido(int dia){
	return (dia>0 && dia<=31);
}

int AnoValido(int ano){
	return ano >= 0;
}

int MesValido(int mes){
	return mes>=1 && mes<=12;
}

int bissexto(int ano){
	if ( ano % 4 == 0 && ano % 100 != 0 ){
		return 1;
	}else{ 
	return 0;
	}if (ano % 400 == 0 )
    return 1;
    
}

int DiaMesValido (int dia, int mes, int ano){
	if (mes == 11 || mes == 4 || mes == 6 || mes == 9){
		if (dia > 0 && dia <= 30){
			return 1;
		}else{
			return 0;
		}		
	}else if (mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12){
			if (dia >= 1 && dia <= 31){
					return 1;
			}else{
				return 0;
	
			}	
	}else if (mes == 2){
		if (bissexto(ano)){
			if (dia>0 && dia<30){
				return 1;
			}else{
				return 0;
			}
		}else if(dia>0 && dia<29){
			return 1;
		}else{
			return 0;
		}
	}
}

void MostraData(hoje){
	Tdata data;
	printf ("Dia DIA: %d", data.dia);
}
	
	


