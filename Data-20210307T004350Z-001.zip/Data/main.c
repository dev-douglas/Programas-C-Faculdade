#include <stdio.h>
#include <stdlib.h>
#include "data.h"

main(){

Tdata hoje;
int dia, mes, ano;
printf ("Digite uma data\n\nDia: ");
scanf("%d", &dia);
printf ("Mes: ");
scanf("%d", &mes);
printf ("Ano: ");
scanf("%d", &ano);
hoje = CriaData(dia,mes,ano);
void MostraData(hoje);

}
