#include <stdio.h>
#include <stdlib.h>
#include "campo.h"
#include <locale.h>

void main(){
	setlocale(LC_ALL,"");
	recebe();	
}
