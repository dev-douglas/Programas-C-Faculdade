#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "campo.h"

campo recebe(void){
	
	campo minado;
	int tab, tab_min, tab_max, **tabuleiro, *bandeiras; 
	char **tabuleiro2;
	
	do{
		system("cls");
		printf("Campo Minado\n\n");
		printf("Digite o n�mero de LINHAS (minimo 3): ");
		scanf("%d", &minado.linhas);
	}while(minado.linhas<3);
	
	do{
	system("cls");
	printf("Campo Minado\n\n");
	printf("Digite o n�mero de COLUNAS (minimo 3): ");
	scanf("%d", &minado.colunas);
	}while(minado.colunas<3);
	tab = minado.linhas*minado.colunas;
   	tab_min = tab * 0.2;
   	tab_max = tab * 0.4;
	do{
	system("cls");
	printf("Campo Minado\n\n");
	printf("Digite a quantidade de bombas. minimo: %d - m�ximo: %d\n\nQuantidade: ", tab_min, tab_max);
	scanf("%d", &minado.bombas);
	minado.bandeira = minado.bombas;
	bandeiras = &minado.bandeira;
	
	}while(minado.bombas<tab_min || minado.bombas>tab_max);
	system("cls");
	tabuleiro = cria_tabuleiro(minado.linhas, minado.colunas, tabuleiro, minado.bombas);
	tabuleiro = quantidade(tabuleiro, minado.linhas, minado.colunas);	
	tabuleiro2 = interface_tabuleiro(tabuleiro2, minado.linhas, minado.colunas);
	while(1==1){
		system("cls");
		mostrar(tabuleiro2, tabuleiro,minado.linhas, minado.colunas);
		acao(minado.linhas, minado.colunas, tabuleiro, tabuleiro2, bandeiras);
	}	
}

char **acao(int linha, int coluna, int **tabuleiro, char **tabuleiro2, int *bandeiras){
	campo minado;
	int l, c, x, y, opcao;
	printf("\n\nDIGITE A POSI��O\n");
	do{
	printf("\nLINHA: ");
	scanf("%d", &l);
	}while(l<0 || l>=linha);
	do{
	printf("COLUNA: ");
	scanf("%d", &c);
	}while(c<0 || c>=coluna);

	do{
		printf("Escolha: 1 - Visitar posi��o 2 - Bandeira[%d] 3 - D�vida\nOp��o: ",*bandeiras);	
		scanf("%d", &opcao);
	}while(opcao<1 || opcao>3);
	
	if(opcao == 1){
		tabuleiro2 = visitar_posicao(tabuleiro, tabuleiro2, l,c, linha, coluna);
		verifica(tabuleiro, tabuleiro2, l,c, linha, coluna);
	}else if(opcao == 2){
	tabuleiro2 = bandeira(tabuleiro2, l, c);
	if(tabuleiro2[l][c]=='B'){
		*bandeiras-=1;
	}else if(tabuleiro2[l][c]=='-'){
		*bandeiras+=1;
	}
	}else if(opcao == 3){
		tabuleiro2 = duvida(tabuleiro2, l, c);
	}	
}

char **visitar_posicao(int **tabuleiro, char **tabuleiro2, int l, int c, int linhas, int colunas){
	if(tabuleiro2[l][c]=='y'){
					printf("A posi��o ja foi visitada!\nPrecione enter para continuar.\n");
					getch();
				}else if(tabuleiro2[l][c]=='B'){
					printf("N�o � possivel visitar a posi��o pois ela cont�m uma bandeira\nPrecione enter para continuar.\n");
					getch();
				}else if(tabuleiro[l][c]==9){
					tabuleiro2[l][c]='y';
					system("cls");
					mostrar(tabuleiro2, tabuleiro,linhas, colunas);
					printf("\n\nFIM DE JOGO - VOC� PERDEU\n");
					system("PAUSE");
					exit(0);
				}else if(tabuleiro2[l][c]=='-'){
						tabuleiro2[l][c]='y';
				}else if(tabuleiro2[l][c]='?'){
					tabuleiro2[l][c]='-';
				}
		return tabuleiro2;		
}

char verifica(int **tabuleiro, char **tabuleiro2, int l, int c, int linhas, int colunas){
	int i=0, j=0, x, y;
	for(i=0;i<linhas;i++){
		for(j=0;j<colunas;j++){
			if(tabuleiro2[i][j]=='-' && tabuleiro[i][j]!=9){
				return 't';
			}else if(tabuleiro2[i][j]=='y' && tabuleiro[i][j]!=9){
			}
		}
	}
	system("cls");
	mostrar(tabuleiro2, tabuleiro,linhas, colunas);
	printf("\n\nParab�ns Voc� Ganhou!\n");
	system("color 0A");
	system("PAUSE");
	exit(0);
}

char **bandeira(char **tabuleiro2, int l, int c){
	if(tabuleiro2[l][c]=='y'){
					printf("A posi��o ja foi visitada!\nPrecione enter para continuar.\n");
					getch();
				}else if(tabuleiro2[l][c]=='B'){
					tabuleiro2[l][c]='-';
				}else{
					tabuleiro2[l][c]='B';
				}
		return tabuleiro2;
}

char **duvida(char **tabuleiro2, int l, int c){
	
	if(tabuleiro2[l][c]=='y'){
					printf("A posi��o ja foi visitada!\nPrecione enter para continuar.\n");
					getch();
				}else if(tabuleiro2[l][c]=='B'){
					printf("A posi��o cont�m uma bandeira!\nPrecione enter para continuar.\n");
					getch();
				}else if(tabuleiro2[l][c]='-'){
					tabuleiro2[l][c]='?';
				}else if(tabuleiro2[l][c]='?'){
					tabuleiro2[l][c]='-';
				}
		return tabuleiro2;
}

void mostrar(char **tabuleiro2, int **tabuleiro, int linhas, int colunas){
	
	int x = 0, y = 0, i, j, d,m, fim = 0;

	while(x<colunas){
		if(x==0){
		printf("    ");	
		}
		if(x>9){
			printf("%d  ", x);	
		}else if(x==linhas-1){
			printf("%d  ", x);	
		}else{
			printf("%d   ", x);	
		}
   		x++;
	   }x=0;
	printf("\n");
	for(i=0; i<linhas;i++){
		 printf("\n");
		 	if(i>9){
	   			printf("%d  ", y);
   			}else{
   				printf("%d   ", y);
			}	
   			y++;			  
   	for(j=0; j<colunas;j++){
   		if(tabuleiro2[i][j]=='y'){
   			if(tabuleiro[i][j]==9){
   					
   				y = 0;
		  			system("cls");
   					while(x<colunas){
						if(x==0){
							printf("    ");	
						}
					if(x>9){
						printf("%d  ", x);	
					}else if(x==linhas-1){
						printf("%d  ", x);	
					}else{
						printf("%d   ", x);	
					}
					x++;
		   			}x=0;
				printf("\n");
				for(i=0; i<linhas;i++){
		 			printf("\n");
		   			if(i>9){
		  			 	printf("%d  ", y);
   					}else{
   						printf("%d   ", y);
					}	
   					y++;			  
	 	  			for(j=0; j<colunas;j++){
   						if(tabuleiro[i][j]==9){
   							printf("X | ");
						}else{
						printf("%d | ",tabuleiro[i][j]);
				   		}
					}
			   	}
				system("color 0C");
   			}else{
				printf("%d | ",tabuleiro[i][j]);
			}	
		}else{
			printf("%c | ",tabuleiro2[i][j]);
		}
	}
	}
}

int **cria_tabuleiro(int linha, int coluna, int **p, int bombas){
	int   i, j, x, y;
	p = (int**) calloc (linha, (sizeof(sizeof(int*))));
	if (p == NULL){
    	printf ("Erro de Memoria\n");
    	return NULL;
    }
	for(i = 0; i<linha; i++){
		p[i] = (int*) calloc (coluna, sizeof(int));
			if (p == NULL) {
    		printf ("Erro de Memoria\n");
    		return NULL;
  			}
   	}
   	for(i = 0; i<bombas;i++){
     	srand(time(NULL));
		x = rand() % linha;
		y = rand() % coluna;
     	if(p[x][y]== 9){	//9 = BOMBA
     		while(p[x][y]== 9){
     			x = rand() % linha;
				y = rand() % coluna;
			}
			p[x][y] = 9;
		 }else{
			p[x][y] = 9;
		 }
  	}
  	return p;
}

char **interface_tabuleiro(char **tabuleiro2, int linhas, int colunas){
	int   i, j;
	tabuleiro2 = (char**) malloc (linhas * (sizeof(sizeof(char*))));
	if (tabuleiro2 == NULL){
    	printf ("Erro de Memoria\n");
    	return NULL;
    }
	for(i = 0; i<linhas; i++){
		tabuleiro2[i] = (char*) malloc (colunas * sizeof(char));
			if (tabuleiro2 == NULL) {
    		printf ("Erro de Memoria\n");
    		return NULL;
  			}
   	}
   	for(i=0; i<linhas;i++){
   		for(j=0; j<colunas;j++){
   			tabuleiro2[i][j] = '-';
		   }
	}
	return tabuleiro2;
}

int **quantidade(int**p, int linha, int coluna){
	int i, j;

	for(i = 0; i<linha; i++){
		for(j = 0;j<coluna; j++){
			if(i ==0 && j ==0){
					if(p[i][j]== 0){
						if(p[i][j+1]==9){
							p[i][j] ++;
						}
						if(p[i+1][j]==9){
							p[i][j] ++;
						}
						if(p[i+1][j+1]==9){
							p[i][j] ++;
						}
					}
			}else if(i == linha-1 && j==0){
				if(p[i][j]==0){
					if(p[i-1][j]==9){
						p[i][j] ++;	
					}
					if(p[i-1][j+1]==9){
						p[i][j] ++;	
					}
					if(p[i][j+1]==9){
						p[i][j] ++;	
					}
				}
			}else if(i==0 && j == coluna-1){
				if(p[i][j]==0){
					if(p[i][j-1]==9){
						p[i][j]++;
					}
					if(p[i+1][j-1]==9){
						p[i][j]++;
					}
					if(p[i+1][j]==9){
						p[i][j]++;
					}
				}
			}else if(i == linha-1 && j==coluna-1){
				if(p[i][j]==0){
					if(p[i][j-1]==9){
						p[i][j]++;
					}
					if(p[i-1][j-1]==9){
						p[i][j]++;
					}
					if(p[i-1][j]==9){
						p[i][j]++;
					}
				}
			}else if(j==0){
				if(p[i][j]==0){
					if(p[i-1][j]==9){
						p[i][0]++;
					}
					if(p[i-1][j+1]==9){
						p[i][0]++;
					}
					if(p[i][j+1]==9){
						p[i][0]++;
					}
					if(p[i+1][j+1]==9){
						p[i][0]++;
					}
					if(p[i+1][j]==9){
						p[i][0]++;
					}
				}
			}else if(i==0){
				if(p[i][j]==0){
					if(p[i][j-1]==9){
						p[i][j]++;
					}
					if(p[i+1][j-1]==9){
						p[i][j]++;
					}
					if(p[i+1][j]==9){
						p[i][j]++;
					}
					if(p[i+1][j+1]==9){
						p[i][j]++;
					}
					if(p[i][j+1]==9){
						p[i][j]++;
					}
				}
			}else if(j == coluna-1){
				if(p[i][j]==0){
					if(p[i-1][j]==9){
						p[i][j]++;
					}
					if(p[i-1][j-1]==9){
						p[i][j]++;
					}
					if(p[i][j-1]==9){
						p[i][j]++;
					}
					if(p[i+1][j-1]==9){
						p[i][j]++;
					}
					if(p[i+1][j]==9){
						p[i][j]++;
					}
				}
			}else if(i == linha-1){
				if(p[i][j]==0){
					if(p[i][j-1]==9){
						p[i][j]++;
					}
					if(p[i-1][j-1]==9){
						p[i][j]++;
					}
					if(p[i-1][j]==9){
						p[i][j]++;
					}
					if(p[i-1][j+1]==9){
						p[i][j]++;
					}
					if(p[i][j+1]==9){
						p[i][j]++;
					}
				}
			}else{
				if(p[i][j]==0){
					if(p[i-1][j-1]==9){
						p[i][j]++;
					}
					if(p[i-1][j]==9){
						p[i][j]++;
					}
					if(p[i-1][j+1]==9){
						p[i][j]++;
					}
					if(p[i][j+1]==9){
						p[i][j]++;
					}
					if(p[i+1][j+1]==9){
						p[i][j]++;
					}
					if(p[i+1][j]==9){
						p[i][j]++;
					}
					if(p[i+1][j-1]==9){
						p[i][j]++;
					}
					if(p[i][j-1]==9){
						p[i][j]++;
					}
				}
			}
		}
	}
	return p;
}
