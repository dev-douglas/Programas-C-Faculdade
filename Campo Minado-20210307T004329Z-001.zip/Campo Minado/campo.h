typedef struct minado{
	int posiceos_tab, linhas , colunas, bombas, bandeira;
	char mina, duvida;
}campo;

campo recebe(void);
// Recebe o numero de linha e colunas do usuario
int **cria_tabuleiro(int linha, int coluna, int **p,int bombas);
/*
Cria o tabuleiro alocado dinamicamente de acordo com o tamanho informado pelo usuario
(linha e coluna nao podem ser inferior a 5)
Distribui as minas (quantidade informada pelo usuario) aleatoriamente
O n�mero de bombas n�o poder� ultrapassar a 40% do n�mero de posi��es do 
tabuleiro e n�o pode ser menos que 20% do n�mero de posi��es do tabuleiro;
*/

char **interface_tabuleiro(char **tabuleiro2, int linhas, int colunas);
/*
fazer uma copia do tabuleiropara para ocultar os locais com bombas
*/

void mostrar(char **tabuleiro2, int **tabuleiro,int linhas, int colunas);
//exibe o tabuleiro para o usuario
char **visitar_posicao(int **tabuleiro, char **tabuleiro2, int l, int c, int linhas, int colunas);
/*
Verifica se a posi��o ja foi marcada, se n�o, ela � marcada, caso haja bomba o jogo termina
*/
char **bandeira(char **tabuleiro2, int l, int c);
//Responsavel por marcar "B" na posi��o escolhida pelo usuario

char **duvida(char **tabuleiro2, int l, int c);
//Responsavel por marcar "?" na posi��o escolhida pelo usuario

char **acao(int linha, int coluna, int **tabuleiro, char **tabuleiro2, int *bandeiras);
/*
Recebe a poci��o e pergunta o usuario o que deseja fazer: Marcar bandeira (B), duvida(?) 
ou visitar posi��o onde pode ter bomba, numeros ou espa�os vazios;
*/

char verifica(int **tabuleiro, char **tabuleiro2, int l, int c, int linhas, int colunas);
/*
Caso o usuario marque todas as op��es que nao contenham bombas, exibir mensagem "VENCEU"
*/

int **quantidade(int**p, int linha, int coluna);
//informar o numero de bombas ao redor das possi��es
